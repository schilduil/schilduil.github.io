vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Aug 2004 10:20:49 -0000
vti_extenderversion:SR|5.0.2.2623
vti_usagebymonth:UX|1 7 3 1 1
vti_usagebyweek:UX|1
vti_usagebyday:UX|1
vti_usagelastupdated:TX|29 Dec 2004 03:02:19 -0000
vti_usagetotalhits:IX|13
