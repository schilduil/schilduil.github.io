<?php

  // Getting the name
  $basename = explode('.', basename($REQUEST_URI));

  // nl-be,nl;q=0.7,en;q=0.3 (IE 6.0)
  // nl-be, nl;q=0.66, en;q=0.33 (Mozilla 1.0)

  // Split up the LANGUAGE string
  $languages = explode(',', str_replace(' ', '', $HTTP_ACCEPT_LANGUAGE));

  // While no language is set with the variables go through the languages
  $count = 0;

  if (!isset($language)) {

    $language = '';

  }

  while (strlen($language) <> 2) {

    if (isset($languages[$count])) {

      switch (substr($languages[$count], 0, 2)) {

        case 'nl':
          $language = 'nl';
          break;
        case 'de':
          $language = 'de';
          break;
        case 'en':
          $language = 'en';
          break;

      }

    } else {

      global $language;
      $language = 'en';

    }

    $count++;

  }

  if ($language == 'en') {

    include($basename[0].'.html');

  } else {

    include($basename[0].'.'.$language.'.html');

  }

?>